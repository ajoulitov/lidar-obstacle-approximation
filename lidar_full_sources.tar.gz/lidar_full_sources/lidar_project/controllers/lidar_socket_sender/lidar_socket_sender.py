from controller import Robot
import numpy as np
import socket
import struct
import time

HOST = '127.0.0.1'
PORT = 5005

robot = Robot()
timestep = int(robot.getBasicTimeStep())

lidar = robot.getDevice('lidar')
lidar.enable(timestep)

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)

while True:
    try:
        sock.connect((HOST, PORT))
        break
    except Exception:
        time.sleep(0.5)

while robot.step(timestep) != -1:
    ranges = np.array(lidar.getRangeImage(), dtype=np.float32)
    fov = float(lidar.getFov())
    width = int(lidar.getHorizontalResolution())
    angles = np.linspace(fov / 2, -fov / 2, width).astype(np.float32)

    mask = (ranges < lidar.getMaxRange()) & (ranges > lidar.getMinRange())
    r_valid = ranges[mask]
    a_valid = angles[mask]

    x = r_valid * np.cos(a_valid)
    y = r_valid * np.sin(a_valid)

    xy = np.stack([x, y], axis=1).astype(np.float32)
    count = xy.shape[0]

    sock.sendall(struct.pack('<I', count))
    if count > 0:
        sock.sendall(xy.tobytes(order='C'))
