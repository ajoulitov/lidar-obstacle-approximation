import matplotlib

matplotlib.use("TkAgg")

import time
import threading
from queue import Queue, Empty
import numpy as np
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import PointCloud2
from sensor_msgs_py import point_cloud2
from geom_core import Point2D, Segment, Circle
from algo import approximate
from visualization import viz

SCALE = 0.05
MAX_RANGE = 5.0
DRAW_DELAY = 0.1


def webots_to_plot(pts: np.ndarray) -> np.ndarray:
    if pts is None or pts.size == 0:
        return np.empty((0, 2), dtype=float)
    x = pts[:, 0]
    y = pts[:, 1]
    plot_x = -y
    plot_y = x
    return np.column_stack((plot_x, plot_y))


def to_point2d_list_scaled_for_algo(pts_plot: np.ndarray):
    if pts_plot is None or pts_plot.size == 0:
        return []
    pts_scaled = pts_plot / SCALE
    return [Point2D(float(x), float(y)) for x, y in pts_scaled]


def scale_primitives_to_plot(segments, circles, scale):
    scaled_segments = []
    scaled_circles = []
    for s in segments:
        p1 = Point2D(s.p1.x * scale, s.p1.y * scale)
        p2 = Point2D(s.p2.x * scale, s.p2.y * scale)
        scaled_segments.append(Segment(p1, p2))
    for c in circles:
        center = Point2D(c.center.x * scale, c.center.y * scale)
        scaled_circles.append(Circle(center, c.radius * scale))
    return scaled_segments, scaled_circles


class LidarAlgoVisualizer(Node):
    def __init__(self):
        super().__init__("lidar_algo_visualizer")

        self._queue: Queue[np.ndarray] = Queue(maxsize=1)
        self._last_algo_run = 0.0

        self.visualizer = viz.Visualizer(max_range=MAX_RANGE, title="Lidar + detected primitives")

        self.sub = self.create_subscription(
            PointCloud2,
            "/lidar/points",
            self._cb,
            10
        )

        self.get_logger().info("Subscribed to /lidar/points")

    def _cb(self, msg: PointCloud2):
        try:
            pts = point_cloud2.read_points_numpy(
                msg,
                field_names=["x", "y", "z"],
                skip_nans=True
            )
            if pts is None or pts.size == 0:
                arr = np.empty((0, 2), dtype=np.float32)
            else:
                pts = np.asarray(pts, dtype=np.float32).reshape((-1, 3))
                arr = pts[:, :2]  # Nx2 (x,y)

            try:
                self._queue.put_nowait(arr)
            except Exception:
                try:
                    _ = self._queue.get_nowait()
                except Exception:
                    pass
                try:
                    self._queue.put_nowait(arr)
                except Exception:
                    pass

        except Exception as e:
            self.get_logger().error(f"PointCloud2 decode error: {e}")

    def run_main_loop(self):
        while rclpy.ok():
            try:
                xy = self._queue.get_nowait()
            except Empty:
                xy = None

            if xy is not None:
                pts_plot_m = webots_to_plot(xy)
                self.visualizer.update_points(pts_plot_m)

                now = time.time()
                if now - self._last_algo_run >= DRAW_DELAY:
                    points_for_algo = to_point2d_list_scaled_for_algo(pts_plot_m)
                    try:
                        segments, circles = approximate(points_for_algo)
                    except Exception as e:
                        self.get_logger().error(f"Error in approximate(): {e}")
                        segments, circles = [], []

                    segs_m, circs_m = scale_primitives_to_plot(segments, circles, SCALE)
                    self.visualizer.update_primitives(segs_m, circs_m)

                    self._last_algo_run = now

            time.sleep(0.01)


def main(args=None):
    rclpy.init(args=args)
    node = LidarAlgoVisualizer()

    t = threading.Thread(target=rclpy.spin, args=(node,), daemon=True)
    t.start()

    try:
        node.run_main_loop()
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
