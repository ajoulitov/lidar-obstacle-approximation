from std_msgs.msg import Header
import socket
import struct
import numpy as np

import rclpy
from rclpy.node import Node

from sensor_msgs.msg import PointCloud2
from sensor_msgs_py import point_cloud2


def recv_exact(conn: socket.socket, n: int) -> bytes:
    buf = b''
    while len(buf) < n:
        chunk = conn.recv(n - len(buf))
        if not chunk:
            raise ConnectionError("socket closed")
        buf += chunk
    return buf


class LidarSocketBridge(Node):
    def __init__(self):
        super().__init__('lidar_socket_bridge')

        self.declare_parameter('bind_ip', '0.0.0.0')
        self.declare_parameter('port', 5005)

        bind_ip = self.get_parameter('bind_ip').value
        port = int(self.get_parameter('port').value)

        self.pub = self.create_publisher(PointCloud2, '/lidar/points', 10)

        self.server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.server.bind((bind_ip, port))
        self.server.listen(1)

        self.get_logger().info(f"Listening TCP on {bind_ip}:{port}")

    def run(self):
        while rclpy.ok():
            self.get_logger().info("Waiting for Webots connection")
            conn, addr = self.server.accept()
            self.get_logger().info(f"Connected: {addr}")
            try:
                while rclpy.ok():
                    header = recv_exact(conn, 4)
                    (count,) = struct.unpack('<I', header)
                    payload = recv_exact(conn, count * 2 * 4)

                    xy = np.frombuffer(payload, dtype=np.float32).reshape((-1, 2))
                    if xy.shape[0] == 0:
                        continue

                    z = np.zeros((xy.shape[0], 1), dtype=np.float32)
                    xyz = np.hstack([xy, z])
                    points = [tuple(p) for p in xyz]

                    header = Header()
                    header.frame_id = 'lidar_frame'
                    msg = point_cloud2.create_cloud_xyz32(header, points)
                    msg.header.stamp = self.get_clock().now().to_msg()
                    self.pub.publish(msg)
            except Exception as e:
                self.get_logger().warn(f"Connection lost: {e}")
            finally:
                try:
                    conn.close()
                except Exception:
                    pass


def main():
    rclpy.init()
    node = LidarSocketBridge()
    try:
        node.run()
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
