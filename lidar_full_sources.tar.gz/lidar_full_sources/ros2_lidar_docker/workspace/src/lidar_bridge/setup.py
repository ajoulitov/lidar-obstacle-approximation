from setuptools import setup, find_packages

package_name = 'lidar_bridge'

setup(
    name=package_name,
    version='0.0.1',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Cristiano Ronaldo',
    maintainer_email='cr7@edu.hse.ru',
    description='LIDAR bridge between Webots and ROS2',
    license='¯\_(ツ)_/¯',
    tests_require=['pytest'],

    entry_points={
        'console_scripts': [
            'lidar_socket_bridge=lidar_bridge.lidar_socket_bridge:main',
            'lidar_algo_visualizer=lidar_bridge.lidar_algo_visualizer:main',
        ],
    },
)

